</div>
            </div>  </div>
        <div class="rightbar-overlay"></div>

                             
<!-- JAVASCRIPT -->
<script src="<?php echo base_url();?>assets/libs/jquery/jquery.min.js"></script>
<script src="<?php echo base_url();?>assets/libs/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="<?php echo base_url();?>assets/libs/metismenu/metisMenu.min.js"></script>
<script src="<?php echo base_url();?>assets/libs/simplebar/simplebar.min.js"></script>
<script src="<?php echo base_url();?>assets/libs/node-waves/waves.min.js"></script>

<script src="<?php echo base_url();?>assets/libs/morris.js/morris.min.js"></script>
<script src="<?php echo base_url();?>assets/libs/raphael/raphael.min.js"></script>


<script src="<?php echo base_url();?>assets/libs/peity/jquery.peity.min.js"></script>

<script src="<?php echo base_url();?>assets/js/pages/dashboard.init.js"></script>

<script src="<?php echo base_url();?>assets/js/app.js"></script>

<!-- Responsive Table js -->
        <script src="<?php echo base_url();?>assets/libs/admin-resources/rwd-table/rwd-table.min.js"></script>

        <!-- Init js -->
        <script src="<?php echo base_url();?>assets/js/pages/table-responsive.init.js"></script>
 <!-- Responsive examples -->
 <script src="<?php echo base_url();?>assets/libs/datatables.net-responsive/js/dataTables.responsive.min.js"></script>
        <script src="<?php echo base_url();?>assets/libs/datatables.net-responsive-bs4/js/responsive.bootstrap4.min.js"></script>

        <!-- Datatable init js -->
         <!-- plugin js -->
         <script src="<?php echo base_url();?>assets/libs/moment/min/moment.min.js"></script>
        <script src="<?php echo base_url();?>assets/libs/jquery-ui-dist/jquery-ui.min.js"></script>
        <script src="<?php echo base_url();?>assets/libs/%40fullcalendar/core/main.min.js"></script>
        <script src="<?php echo base_url();?>assets/libs/%40fullcalendar/bootstrap/main.min.js"></script>
        <script src="<?php echo base_url();?>assets/libs/%40fullcalendar/daygrid/main.min.js"></script>
        <script src="<?php echo base_url();?>assets/libs/%40fullcalendar/timegrid/main.min.js"></script>
        <script src="<?php echo base_url();?>assets/libs/%40fullcalendar/interaction/main.min.js"></script>
        
        <!-- Calendar init -->
        <script src="<?php echo base_url();?>assets/js/pages/calendar.init.js"></script>
        
        
        <script src="<?php echo base_url();?>assets/js/app.js"></script>
                      
        <!-- JAVASCRIPT -->
        <script src="<?php echo base_url();?>assets/libs/jquery/jquery.min.js"></script>
        <script src="<?php echo base_url();?>assets/libs/bootstrap/js/bootstrap.bundle.min.js"></script>
        <script src="<?php echo base_url();?>assets/libs/metismenu/metisMenu.min.js"></script>
        <script src="<?php echo base_url();?>assets/libs/simplebar/simplebar.min.js"></script>
        <script src="<?php echo base_url();?>assets/libs/node-waves/waves.min.js"></script>

        <!-- Required datatable js -->
        <script src="<?php echo base_url();?>assets/libs/datatables.net/js/jquery.dataTables.min.js"></script>
        <script src="<?php echo base_url();?>assets/libs/datatables.net-bs4/js/dataTables.bootstrap4.min.js"></script>
        <!-- Buttons examples -->
        <script src="<?php echo base_url();?>assets/libs/datatables.net-buttons/js/dataTables.buttons.min.js"></script>
        <script src="<?php echo base_url();?>assets/libs/datatables.net-buttons-bs4/js/buttons.bootstrap4.min.js"></script>
        <script src="<?php echo base_url();?>assets/libs/jszip/jszip.min.js"></script>
        <script src="<?php echo base_url();?>assets/libs/pdfmake/build/pdfmake.min.js"></script>
        <script src="<?php echo base_url();?>assets/libs/pdfmake/build/vfs_fonts.js"></script>
        <script src="<?php echo base_url();?>assets/libs/datatables.net-buttons/js/buttons.html5.min.js"></script>
        <script src="<?php echo base_url();?>assets/libs/datatables.net-buttons/js/buttons.print.min.js"></script>
        <script src="<?php echo base_url();?>assets/libs/datatables.net-buttons/js/buttons.colVis.min.js"></script>
        <!-- Responsive examples -->
        <script src="<?php echo base_url();?>assets/libs/datatables.net-responsive/js/dataTables.responsive.min.js"></script>
        <script src="<?php echo base_url();?>assets/libs/datatables.net-responsive-bs4/js/responsive.bootstrap4.min.js"></script>

        <!-- Datatable init js -->
        <script src="<?php echo base_url();?>assets/js/pages/datatables.init.js"></script> 

       
       
       
   
     
       

        <!-- Sweet Alerts js -->
        <script src="<?php echo base_url();?>assets/libs/sweetalert2/sweetalert2.min.js"></script>

        <!-- Sweet alert init js-->
        <script src="<?php echo base_url();?>assets/js/pages/sweet-alerts.init.js"></script>

        
        <script src="<?php echo base_url();?>assets/libs/bootstrap/js/bootstrap.bundle.min.js"></script>
        <script src="<?php echo base_url();?>assets/libs/metismenu/metisMenu.min.js"></script>
        <script src="<?php echo base_url();?>assets/libs/simplebar/simplebar.min.js"></script>
        <script src="<?php echo base_url();?>assets/libs/node-waves/waves.min.js"></script>

        <!-- Sweet Alerts js -->
        <script src="<?php echo base_url();?>assets/libs/sweetalert2/sweetalert2.min.js"></script>

        <!-- Sweet alert init js-->
        <script src="<?php echo base_url();?>assets/js/pages/sweet-alerts.init.js"></script>

        <script src="<?php echo base_url();?>assets/js/app.js"></script>
</body>

<!-- Mirrored from themesbrand.com/foxia/layouts/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 07 Jun 2023 17:49:41 GMT -->
</html>
