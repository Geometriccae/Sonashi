<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-10-11 12:46:49 --> Config Class Initialized
INFO - 2023-10-11 12:46:49 --> Hooks Class Initialized
DEBUG - 2023-10-11 12:46:49 --> UTF-8 Support Enabled
INFO - 2023-10-11 12:46:49 --> Utf8 Class Initialized
INFO - 2023-10-11 12:46:49 --> URI Class Initialized
INFO - 2023-10-11 12:46:49 --> Router Class Initialized
INFO - 2023-10-11 12:46:49 --> Output Class Initialized
INFO - 2023-10-11 12:46:49 --> Security Class Initialized
DEBUG - 2023-10-11 12:46:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-11 12:46:49 --> Input Class Initialized
INFO - 2023-10-11 12:46:49 --> Language Class Initialized
INFO - 2023-10-11 12:46:49 --> Loader Class Initialized
INFO - 2023-10-11 12:46:49 --> Helper loaded: url_helper
INFO - 2023-10-11 12:46:49 --> Helper loaded: file_helper
INFO - 2023-10-11 12:46:49 --> Database Driver Class Initialized
INFO - 2023-10-11 12:46:49 --> Email Class Initialized
DEBUG - 2023-10-11 12:46:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-11 12:46:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-11 12:46:49 --> Controller Class Initialized
INFO - 2023-10-11 12:46:49 --> Model "User_admin_model" initialized
DEBUG - 2023-10-11 12:46:49 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-10-11 12:46:49 --> Severity: Warning --> Undefined property: User_admin::$UserModel C:\xampp\htdocs\ges-crm\application\controllers\User_admin.php 23
ERROR - 2023-10-11 12:46:49 --> Severity: error --> Exception: Call to a member function authenticate() on null C:\xampp\htdocs\ges-crm\application\controllers\User_admin.php 23
INFO - 2023-10-11 12:46:51 --> Config Class Initialized
INFO - 2023-10-11 12:46:51 --> Hooks Class Initialized
DEBUG - 2023-10-11 12:46:51 --> UTF-8 Support Enabled
INFO - 2023-10-11 12:46:51 --> Utf8 Class Initialized
INFO - 2023-10-11 12:46:51 --> URI Class Initialized
INFO - 2023-10-11 12:46:51 --> Router Class Initialized
INFO - 2023-10-11 12:46:51 --> Output Class Initialized
INFO - 2023-10-11 12:46:51 --> Security Class Initialized
DEBUG - 2023-10-11 12:46:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-11 12:46:51 --> Input Class Initialized
INFO - 2023-10-11 12:46:51 --> Language Class Initialized
INFO - 2023-10-11 12:46:51 --> Loader Class Initialized
INFO - 2023-10-11 12:46:51 --> Helper loaded: url_helper
INFO - 2023-10-11 12:46:51 --> Helper loaded: file_helper
INFO - 2023-10-11 12:46:51 --> Database Driver Class Initialized
INFO - 2023-10-11 12:46:51 --> Email Class Initialized
DEBUG - 2023-10-11 12:46:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-11 12:46:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-11 12:46:51 --> Controller Class Initialized
INFO - 2023-10-11 12:46:51 --> Model "Lead_model" initialized
INFO - 2023-10-11 12:46:51 --> Model "Lead_source_model" initialized
INFO - 2023-10-11 12:46:51 --> Model "Lead_status_model" initialized
INFO - 2023-10-11 12:46:51 --> Model "LeadServicesRequired_model" initialized
ERROR - 2023-10-11 12:46:51 --> Severity: Warning --> Undefined array key "admin_uid" C:\xampp\htdocs\ges-crm\application\controllers\Admin.php 48
INFO - 2023-10-11 12:46:51 --> File loaded: C:\xampp\htdocs\ges-crm\application\views\admin/login.php
INFO - 2023-10-11 12:46:51 --> Final output sent to browser
DEBUG - 2023-10-11 12:46:51 --> Total execution time: 0.0551
INFO - 2023-10-11 12:46:54 --> Config Class Initialized
INFO - 2023-10-11 12:46:54 --> Hooks Class Initialized
DEBUG - 2023-10-11 12:46:54 --> UTF-8 Support Enabled
INFO - 2023-10-11 12:46:54 --> Utf8 Class Initialized
INFO - 2023-10-11 12:46:54 --> URI Class Initialized
INFO - 2023-10-11 12:46:54 --> Router Class Initialized
INFO - 2023-10-11 12:46:54 --> Output Class Initialized
INFO - 2023-10-11 12:46:54 --> Security Class Initialized
DEBUG - 2023-10-11 12:46:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-11 12:46:54 --> Input Class Initialized
INFO - 2023-10-11 12:46:54 --> Language Class Initialized
INFO - 2023-10-11 12:46:54 --> Loader Class Initialized
INFO - 2023-10-11 12:46:54 --> Helper loaded: url_helper
INFO - 2023-10-11 12:46:54 --> Helper loaded: file_helper
INFO - 2023-10-11 12:46:54 --> Database Driver Class Initialized
INFO - 2023-10-11 12:46:54 --> Email Class Initialized
DEBUG - 2023-10-11 12:46:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-11 12:46:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-11 12:46:54 --> Controller Class Initialized
INFO - 2023-10-11 12:46:54 --> Model "User_admin_model" initialized
DEBUG - 2023-10-11 12:46:54 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-10-11 12:46:54 --> Severity: Warning --> Undefined property: User_admin::$UserModel C:\xampp\htdocs\ges-crm\application\controllers\User_admin.php 23
ERROR - 2023-10-11 12:46:54 --> Severity: error --> Exception: Call to a member function authenticate() on null C:\xampp\htdocs\ges-crm\application\controllers\User_admin.php 23
INFO - 2023-10-11 12:46:56 --> Config Class Initialized
INFO - 2023-10-11 12:46:56 --> Hooks Class Initialized
DEBUG - 2023-10-11 12:46:56 --> UTF-8 Support Enabled
INFO - 2023-10-11 12:46:56 --> Utf8 Class Initialized
INFO - 2023-10-11 12:46:56 --> URI Class Initialized
INFO - 2023-10-11 12:46:56 --> Router Class Initialized
INFO - 2023-10-11 12:46:56 --> Output Class Initialized
INFO - 2023-10-11 12:46:56 --> Security Class Initialized
DEBUG - 2023-10-11 12:46:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-11 12:46:56 --> Input Class Initialized
INFO - 2023-10-11 12:46:56 --> Language Class Initialized
INFO - 2023-10-11 12:46:56 --> Loader Class Initialized
INFO - 2023-10-11 12:46:56 --> Helper loaded: url_helper
INFO - 2023-10-11 12:46:56 --> Helper loaded: file_helper
INFO - 2023-10-11 12:46:56 --> Database Driver Class Initialized
INFO - 2023-10-11 12:46:56 --> Email Class Initialized
DEBUG - 2023-10-11 12:46:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-11 12:46:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-11 12:46:56 --> Controller Class Initialized
INFO - 2023-10-11 12:46:56 --> Model "Lead_model" initialized
INFO - 2023-10-11 12:46:56 --> Model "Lead_source_model" initialized
INFO - 2023-10-11 12:46:56 --> Model "Lead_status_model" initialized
INFO - 2023-10-11 12:46:56 --> Model "LeadServicesRequired_model" initialized
ERROR - 2023-10-11 12:46:56 --> Severity: Warning --> Undefined array key "admin_uid" C:\xampp\htdocs\ges-crm\application\controllers\Admin.php 48
INFO - 2023-10-11 12:46:56 --> File loaded: C:\xampp\htdocs\ges-crm\application\views\admin/login.php
INFO - 2023-10-11 12:46:56 --> Final output sent to browser
DEBUG - 2023-10-11 12:46:56 --> Total execution time: 0.0561
INFO - 2023-10-11 12:47:04 --> Config Class Initialized
INFO - 2023-10-11 12:47:04 --> Hooks Class Initialized
DEBUG - 2023-10-11 12:47:04 --> UTF-8 Support Enabled
INFO - 2023-10-11 12:47:04 --> Utf8 Class Initialized
INFO - 2023-10-11 12:47:04 --> URI Class Initialized
INFO - 2023-10-11 12:47:04 --> Router Class Initialized
INFO - 2023-10-11 12:47:04 --> Output Class Initialized
INFO - 2023-10-11 12:47:04 --> Security Class Initialized
DEBUG - 2023-10-11 12:47:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-11 12:47:04 --> Input Class Initialized
INFO - 2023-10-11 12:47:04 --> Language Class Initialized
INFO - 2023-10-11 12:47:04 --> Loader Class Initialized
INFO - 2023-10-11 12:47:04 --> Helper loaded: url_helper
INFO - 2023-10-11 12:47:04 --> Helper loaded: file_helper
INFO - 2023-10-11 12:47:04 --> Database Driver Class Initialized
INFO - 2023-10-11 12:47:04 --> Email Class Initialized
DEBUG - 2023-10-11 12:47:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-11 12:47:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-11 12:47:04 --> Controller Class Initialized
INFO - 2023-10-11 12:47:04 --> Model "User_admin_model" initialized
DEBUG - 2023-10-11 12:47:04 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-10-11 12:47:04 --> Severity: Warning --> Undefined property: User_admin::$UserModel C:\xampp\htdocs\ges-crm\application\controllers\User_admin.php 23
ERROR - 2023-10-11 12:47:04 --> Severity: error --> Exception: Call to a member function authenticate() on null C:\xampp\htdocs\ges-crm\application\controllers\User_admin.php 23
INFO - 2023-10-11 12:49:07 --> Config Class Initialized
INFO - 2023-10-11 12:49:07 --> Hooks Class Initialized
DEBUG - 2023-10-11 12:49:07 --> UTF-8 Support Enabled
INFO - 2023-10-11 12:49:07 --> Utf8 Class Initialized
INFO - 2023-10-11 12:49:07 --> URI Class Initialized
INFO - 2023-10-11 12:49:07 --> Router Class Initialized
INFO - 2023-10-11 12:49:07 --> Output Class Initialized
INFO - 2023-10-11 12:49:07 --> Security Class Initialized
DEBUG - 2023-10-11 12:49:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-11 12:49:07 --> Input Class Initialized
INFO - 2023-10-11 12:49:07 --> Language Class Initialized
INFO - 2023-10-11 12:49:07 --> Loader Class Initialized
INFO - 2023-10-11 12:49:07 --> Helper loaded: url_helper
INFO - 2023-10-11 12:49:07 --> Helper loaded: file_helper
INFO - 2023-10-11 12:49:07 --> Database Driver Class Initialized
INFO - 2023-10-11 12:49:07 --> Email Class Initialized
DEBUG - 2023-10-11 12:49:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-11 12:49:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-11 12:49:07 --> Controller Class Initialized
INFO - 2023-10-11 12:49:07 --> Model "User_admin_model" initialized
DEBUG - 2023-10-11 12:49:07 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-10-11 12:49:07 --> Severity: Warning --> Undefined property: User_admin::$UserModel C:\xampp\htdocs\ges-crm\application\controllers\User_admin.php 23
ERROR - 2023-10-11 12:49:07 --> Severity: error --> Exception: Call to a member function authenticate() on null C:\xampp\htdocs\ges-crm\application\controllers\User_admin.php 23
INFO - 2023-10-11 12:50:59 --> Config Class Initialized
INFO - 2023-10-11 12:50:59 --> Hooks Class Initialized
DEBUG - 2023-10-11 12:50:59 --> UTF-8 Support Enabled
INFO - 2023-10-11 12:50:59 --> Utf8 Class Initialized
INFO - 2023-10-11 12:50:59 --> URI Class Initialized
INFO - 2023-10-11 12:50:59 --> Router Class Initialized
INFO - 2023-10-11 12:50:59 --> Output Class Initialized
INFO - 2023-10-11 12:50:59 --> Security Class Initialized
DEBUG - 2023-10-11 12:50:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-11 12:50:59 --> Input Class Initialized
INFO - 2023-10-11 12:50:59 --> Language Class Initialized
INFO - 2023-10-11 12:50:59 --> Loader Class Initialized
INFO - 2023-10-11 12:50:59 --> Helper loaded: url_helper
INFO - 2023-10-11 12:50:59 --> Helper loaded: file_helper
INFO - 2023-10-11 12:50:59 --> Database Driver Class Initialized
INFO - 2023-10-11 12:50:59 --> Email Class Initialized
DEBUG - 2023-10-11 12:50:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-11 12:50:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-11 12:50:59 --> Controller Class Initialized
INFO - 2023-10-11 12:50:59 --> Model "User_admin_model" initialized
DEBUG - 2023-10-11 12:50:59 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-10-11 12:50:59 --> Severity: Warning --> Undefined property: User_admin::$UserModel C:\xampp\htdocs\ges-crm\application\controllers\User_admin.php 22
ERROR - 2023-10-11 12:50:59 --> Severity: error --> Exception: Call to a member function authenticate() on null C:\xampp\htdocs\ges-crm\application\controllers\User_admin.php 22
INFO - 2023-10-11 12:51:01 --> Config Class Initialized
INFO - 2023-10-11 12:51:01 --> Hooks Class Initialized
DEBUG - 2023-10-11 12:51:01 --> UTF-8 Support Enabled
INFO - 2023-10-11 12:51:01 --> Utf8 Class Initialized
INFO - 2023-10-11 12:51:01 --> URI Class Initialized
INFO - 2023-10-11 12:51:01 --> Router Class Initialized
INFO - 2023-10-11 12:51:01 --> Output Class Initialized
INFO - 2023-10-11 12:51:01 --> Security Class Initialized
DEBUG - 2023-10-11 12:51:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-11 12:51:01 --> Input Class Initialized
INFO - 2023-10-11 12:51:01 --> Language Class Initialized
INFO - 2023-10-11 12:51:01 --> Loader Class Initialized
INFO - 2023-10-11 12:51:01 --> Helper loaded: url_helper
INFO - 2023-10-11 12:51:01 --> Helper loaded: file_helper
INFO - 2023-10-11 12:51:01 --> Database Driver Class Initialized
INFO - 2023-10-11 12:51:01 --> Email Class Initialized
DEBUG - 2023-10-11 12:51:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-11 12:51:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-11 12:51:01 --> Controller Class Initialized
INFO - 2023-10-11 12:51:01 --> Model "User_admin_model" initialized
DEBUG - 2023-10-11 12:51:01 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-10-11 12:51:01 --> Severity: Warning --> Undefined property: User_admin::$UserModel C:\xampp\htdocs\ges-crm\application\controllers\User_admin.php 22
ERROR - 2023-10-11 12:51:01 --> Severity: error --> Exception: Call to a member function authenticate() on null C:\xampp\htdocs\ges-crm\application\controllers\User_admin.php 22
ERROR - 2023-10-11 13:05:09 --> Severity: Warning --> Undefined property: User_admin::$UserModel C:\xampp\htdocs\ges-crm\application\controllers\User_admin.php 21
ERROR - 2023-10-11 13:05:09 --> Severity: error --> Exception: Call to a member function authenticate() on null C:\xampp\htdocs\ges-crm\application\controllers\User_admin.php 21
ERROR - 2023-10-11 13:05:11 --> Severity: Warning --> Undefined property: User_admin::$UserModel C:\xampp\htdocs\ges-crm\application\controllers\User_admin.php 21
ERROR - 2023-10-11 13:05:11 --> Severity: error --> Exception: Call to a member function authenticate() on null C:\xampp\htdocs\ges-crm\application\controllers\User_admin.php 21
