<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Store_location_model extends CI_Model {

    public function __construct() {
        parent::__construct();
        $this->load->database(); // Load database in the constructor
    }

    // Fetch all locations from the store_location table
    public function get_locations() {
        $query = $this->db->get('store_location');
        return $query->result_array();
    }
    public function get_locations_with_routes() {
        $this->db->select('location, routes');
        $query = $this->db->get('store_location');
        return $query->result_array();
    }
    
    // You can add more methods here for other operations like adding, updating, or deleting locations if needed
}
